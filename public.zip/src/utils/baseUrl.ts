// // // export const baseUrl = 'http://161.35.153.209:5430/api/login'
// export const apiHost = "bayut.p.rapidapi.com"
// export const apiKey  = "1bcc9b866emsh40630f96ee03db3p1e058fjsn334dd3ff89cf"
// export const baseUrl = 'https://bayut.p.rapidapi.com/agencies/list?query=patriot&hitsPerPage=25&page=0&lang=en'
export const apiHost = "bayut.p.rapidapi.com"
export const apiKey  = "1bcc9b866emsh40630f96ee03db3p1e058fjsn334dd3ff89cf"
export const baseUrl = 'https://bayut.p.rapidapi.com'

