// import { configureStore } from '@reduxjs/toolkit';
// import { homeApi } from './Api/getpropertieslistApi';

// const store = configureStore({
//   reducer: {
//     // добавьте ваш редьюсер
//     [homeApi.reducerPath]: homeApi.reducer,
//   },
//   middleware: (getDefaultMiddleware) =>
//     getDefaultMiddleware().concat(homeApi.middleware),
// });

// export default store;
