import styled from "styled-components"


export const SCAppButton = styled.button`
    background-color: white;
    color: white;
    width: auto;
    margin-bottom: 30px;
    border-radius: 15px;
  
`