import styled from "styled-components";
export const SCButtonSearch = styled.div`
.Search_input{
    color: #000000;
    width: 575px;
    height: 48px;
    border-radius: 30px;
}


`