import { SCButtonSearch } from './ButtonSearch.style';
export const ButtonSearch = () => {
    return(
    <SCButtonSearch>
         <div className="Search_bottom">
                <input type="text" className="Search_input" />
            </div>
    </SCButtonSearch>
    )}